
export const logMessage = (msg: string) => () => {
  console.log(msg);
}
