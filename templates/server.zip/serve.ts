import { main } from './output/Main/index.js';

main();
